public class SampleTest {
    @org.junit.Test
    public void sampleTest() {
        org.junit.Assert.assertTrue(true);
    }
}
